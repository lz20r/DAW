<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Alquiler de Coches de Lujo en Toda España - GT Rentals</title>
    <link rel="stylesheet" href="assets/css/styles.css" />
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet" />

    <style>
        .carousel-item {
            position: relative;
            width: 100%;
            height: 500px;
            overflow: hidden;
        }

        .video-background {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            z-index: -1;
        }

        .overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 0;
        }

        .navbar {
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 2;
            background-color: transparent;
            padding-left: 1rem;
            padding-right: 1rem;
        }

        .navbar .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .navbar .navbar-nav .nav-link {
            color: white;
        }

        .navbar .navbar-nav .nav-link:hover {
            color: #ccc;
        }

        .navbar .navbar-brand img {
            height: 80px;
        }

        @media (max-width: 576px) {
            .navbar {
                padding-left: 1.5rem;
                padding-right: 1.5rem;
            }

        }

        /* Contenido sobre el video */
        .carousel-caption {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: white;
            text-align: center;
            z-index: 1;
        }

        .navbar-toggler {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1001;
        }

        .navbar-toggler-icon {
            display: inline-block;
            width: 24px;
            height: 2px;
            background-color: white;
            position: relative;
            transition: all 0.3s ease-in-out;
        }

        .navbar-toggler-icon::before,
        .navbar-toggler-icon::after {
            content: '';
            width: 24px;
            height: 2px;
            background-color: white;
            position: absolute;
            left: 0;
            transition: all 0.3s ease-in-out;
        }

        .navbar-toggler-icon::before {
            top: -8px;
        }

        .navbar-toggler-icon::after {
            top: 8px;
        }

        .navbar-toggler.collapsed .navbar-toggler-icon {
            background-color: white;
        }

        .navbar-toggler:not(.collapsed) .navbar-toggler-icon {
            background-color: transparent;
        }

        .navbar-toggler:not(.collapsed) .navbar-toggler-icon::before {
            transform: rotate(45deg);
            top: 0;
        }

        .navbar-toggler:not(.collapsed) .navbar-toggler-icon::after {
            transform: rotate(-45deg);
            top: 0;
        }

        /* Menú de pantalla completa y fondo negro en móviles */
        .navbar-collapse {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100vh;
            background-color: #000;
            z-index: 1000;
            justify-content: center;
            align-items: center;
            opacity: 0;
            visibility: hidden;
            transition: opacity 0.3s ease-in-out, visibility 0.3s ease-in-out;
        }

        .navbar-collapse.show {
            opacity: 1;
            visibility: visible;
        }

        .navbar-nav {
            flex-direction: column;
        }

        .navbar-nav .nav-link {
            color: white;
            font-size: 1.5rem;
            margin: 10px 0;
            text-align: center;
        }

        .navbar-nav .nav-link:hover {
            color: #ccc;
        }

        /* Estructura de la barra de navegación en pantallas grandes */
        @media (min-width: 992px) {
            .navbar-collapse {
                position: static;
                background-color: transparent;
                height: auto;
                justify-content: flex-end;
                opacity: 1 !important;
                visibility: visible !important;
            }

            .navbar-nav {
                display: flex;
                flex-direction: row;
                align-items: center;
            }

            .navbar-nav .nav-link {
                font-size: 1rem;
                margin: 0 10px;
                text-align: left;
            }
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container">
            <a class="navbar-brand" href="#">
                <img src="../assets/img/flipicar.png" alt="Logo">
            </a>
            <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <!-- Logo dentro del navbar-collapse -->
                <a class="navbar-brand d-lg-none mx-auto" href="#">
                    <img src="../assets/img/flipicar.png" alt="Logo"
                        style="height: 80px; margin-top: 1rem; margin-left: 1rem;">
                </a>

                <!-- Elementos de navegación -->
                <ul class="navbar-nav" style="margin-top: 1rem;">
                    <li class="nav-item">
                        <a class="nav-link" href="#inicio">Inicio</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#sobreNosotros">Sobre Nosotros</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#servicios">Servicios</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#modelos">Modelos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#contacto">Contacto</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#login">Login</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Carrusel de videos -->
    <div id="videoCarousel" class="carousel slide background-header" data-ride="carousel">
        <div class="carousel-inner">
            <!-- Video 1 -->
            <div class="carousel-item active">
                <video autoplay muted loop playsinline class="video-background">
                    <source src="https://gtrentals.es/wp-content/uploads/2023/02/banner-home-slider-ruta.mp4"
                        type="video/mp4">
                    Tu navegador no soporta la reproducción de video.
                </video>
                <div class="overlay"></div>
                <div class="carousel-caption">
                    <h1 class="display-4">Alquila tu deportivo</h1>
                    <p class="lead">Experiencias de conducción de lujo en toda España.</p>
                    <a href="#modelos" class="btn btn-primary btn-lg">Ver Modelos</a>
                </div>
            </div>

            <!-- Video 2 -->
            <div class="carousel-item">
                <video autoplay muted loop playsinline class="video-background">
                    <source src="https://gtrentals.es/wp-content/uploads/2023/02/otro-video.mp4" type="video/mp4">
                    Tu navegador no soporta la reproducción de video.
                </video>
                <div class="overlay"></div>
                <div class="carousel-caption">
                    <h1 class="display-4">Vive la velocidad</h1>
                    <p class="lead">Conduce los mejores coches en los mejores lugares.</p>
                    <a href="#modelos" class="btn btn-primary btn-lg">Explorar Modelos</a>
                </div>
            </div>
        </div>

        <!-- Controles de navegación -->
        <a class="carousel-control-prev" href="#videoCarousel" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Anterior</span>
        </a>
        <a class="carousel-control-next" href="#videoCarousel" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Siguiente</span>
        </a>
    </div>

    <section class="container mt-5" id="ofrecemos">
        <div class="row">
            <div class="col-md-6">
                <h2>Ofrecemos</h2>
                <p>Alquiler de coches de lujo en toda España.</p>
                <p>Rutas en deportivos de lujo.</p>
            </div>
            <div class="col-md-6">
                <img src="https://gtrentals.es/wp-content/uploads/2024/03/1-IMG_6324-scaled.jpg" class="img-fluid"
                    alt="Imagen de coches de lujo" />
            </div>
        </div>
    </section>

    <footer class="bg-light text-center py-4" id="contacto">
        <p>&copy; 2024 GT Rentals. Todos los derechos reservados.</p>
        <a href="mailto:info@gtrentals.es">info@gtrentals.es</a>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>